
--[[
	
	

- - -1.7
○ Chat will no longer pass the right edge of the screen and come back for scenes such as Mail
○ Chat should no longer reset position if scene has shown while chat was moving.

- - -1.6.1
○ removed debug text output.

- - -1.6
○ updated api version to 101038
○ improved hud meters platform change functionality
○ improved loot history functionality

- - -1.5
○ updated to U38 api
○ added a reset anchor to chat for when it is supposed to be back in it's original position 
-- to prevent chat from ending up off screen or other positions when it shouldn't be

- - -1.4
○ improved chat repositioning
-- attempt to fix chat getting reset in the wrong place
○ fixed chat positioning not working properly in housing editor.

- - -1.3.2
○ fixed error caused by addition of "rapport adjustment Type" when adjusting loot history settings.

- - -1.3.1
○ added support for gamepad dialogues.

- - -1.3
○ updated for API 101034.

1.2
○ user:/AddOns/IsJustaGamepadUIVisibility/IsJustaGamepadUIVisibility.lua:242: function expected instead of nil - should now be fixed
○ added French translation courtesy of fzr6n7
○ rewrote loot history and dynamic chat window position - mainly just changed the	 format of the code for loot history
○ improved chat position handling.
	- it no longer uses update loops to watch for changing UI elements. 
	- should not "bounce" if chat was closed prior to returning back to HUD
	- stopped screen flash caused by re-anchoring when chat was already in saved position
○ added some support for KelapadUI
○ added simple move
○ 
○ ----------------------
○ improved loot history handling, will now enable/disable properly
○ demo loot will now be visible in options when making a change to loot history options
○ loot history should now appear over other elements
○ loot history row dimensions are now dynamically set based on font size and text height
○ ----------------------
○ added ability to move hud meters (Telvar, Infamy, and Daedric energy)
○ 
○ 
○ 
○ 

1.2.2
○ fixed error /EsoUI/Libraries/Globals/Globals.lua:128: operator < is not supported for number < nil


campaigns initially breaks position

loot history line height not matching up for crafting materials - with statusIcon


i joined a group. traveled to leader. not sure the cause, but when i went to look thru my inventory positioning was not working
had position not work for crown crate scene


check instant positioning on settings change
currently it is direct anchor
do i want it to slide 

]]

local addonInfo = {
	displayName = "|cFF00FFIsJusta|r |cffffffGamepad UI Visibility Helper|r",
	name = "IsJustaGamepadUIVisibility",
	version = "1.7",
}

local defaults = {
	lootHistoryOverlayFont = "ZoFontGamepad22",
	lootHistoryLabelFont = "ZoFontGamepad22",
	scale = 1,
}

local svVersion = 1

local isGamepadMode

--local options = {'moveLootHistory', 'dynamicChatPosition', 'moveHudMeters', 'resizeActionBar'}
local options = {'moveLootHistory', 'dynamicChatPosition', 'moveHudMeters'}
--------------------------------------------------------------------------------
-- Loot history
--------------------------------------------------------------------------------
local function showLootDemo()
	--ZO_LootHistory_Shared:OnNewItemReceived(itemLinkOrName, stackCount, itemSound, lootType, questItemIcon, itemId, isVirtual, isStolen)
	--	/script SYSTEMS:GetObject(ZO_LOOT_HISTORY_NAME):OnNewItemReceived('|H0:item:45854:30:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h', 52, nil, nil, nil, 45854, nil, false)

	local lootHistoy = SYSTEMS:GetObject(ZO_LOOT_HISTORY_NAME)
	
	lootHistoy:AddXpEntry(20000)
	lootHistoy:OnNewItemReceived('|H0:item:45854:30:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h', 52, nil, nil, nil, 45854, nil, false)
	lootHistoy:OnNewItemReceived('|H0:item:135150:30:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h', 10, nil, nil, nil, 135150, nil, true)
	lootHistoy:OnNewItemReceived('|H0:item:30157:30:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h', 10, nil, nil, nil, 30157, nil, false)
	lootHistoy:OnNewItemReceived('|H0:item:23117:30:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h', 10, nil, nil, nil, 23117, true, false)
	lootHistoy:OnNewItemReceived('|H0:item:68247:30:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h', 10, nil, nil, nil, 68247, true, false)
	
	local activeCompanion = GetActiveCompanionDefId()
	activeCompanion = activeCompanion > 0 and activeCompanion or 1
	if activeCompanion > 0 then
		lootHistoy:OnCompanionRapportUpdate(activeCompanion, 900, 1, 1) -- - 899
		lootHistoy:OnCompanionRapportUpdate(activeCompanion, 1, 10, 1) -- + 9
		
		--	object:OnCompanionRapportUpdate(companionId, previousRapport, currentRapport, adjustmentAmountType)
		lootHistoy:OnCompanionExperienceGainUpdate(activeCompanion, 19, 1000, 19000)
	end
end

local fontList = {
	[1] = "ZoFontGamepad18",
	[2] = "ZoFontGamepad20",
	[3] = "ZoFontGamepad22",
	[4] = "ZoFontGamepad25",
	[5] = "ZoFontGamepad27",
	[6] = "ZoFontGamepad34",
	[7] = "ZoFontGamepad36",
	[8] = "ZoFontGamepad42",
}

local fontSizes = {}
do
	for k, fontString in ipairs(fontList) do
		local fontSize = fontString:gsub('%D+', '')
		fontSizes[#fontSizes + 1] = GetString(SI_CHAT_OPTIONS_FONT_SIZE) .. fontSize
	end
end

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

local UIVisibility = ZO_InitializingObject:Subclass()

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

function UIVisibility:Initialize(control)
	self.control = control
	zo_mixin(self, addonInfo)
	
	local function OnLoaded(_, name)
		if name ~= self.name then return end
		
		local AccountWideSavedVars = ZO_SavedVars:NewAccountWide("IJA_GamepadUIVisibility_SavedVars", svVersion, nil, defaults, GetWorldName())
		self.savedVars = AccountWideSavedVars
		
		local function onPlayerActivated()
			control:UnregisterForEvent(EVENT_PLAYER_ACTIVATED)
		--	d( self.displayName .. " version: " .. self.version)
			
			local function onGamepadPreferredModeChanged()
				isGamepadMode = IsInGamepadPreferredMode()
				
				for _, option in pairs(options) do
					self:ToggleOption(option)
				end
			end
			ZO_PlatformStyle:New(onGamepadPreferredModeChanged)
			
			self:SetupSettings()
		end
		control:RegisterForEvent(EVENT_PLAYER_ACTIVATED, onPlayerActivated)
	end
    control:RegisterForEvent( EVENT_ADD_ON_LOADED, OnLoaded)
end

--------------------------------------------------------------------------------
-- Toggle features
--------------------------------------------------------------------------------

local toggleOptions = {
	['moveLootHistory'] = function(self, enabled)
	--	if not enabled and not self.lootHistory then return end
		
		if not self.lootHistory then
			self.lootHistory = IJA_GamepadUIVisibility_LootHistory_Initialize(enabled, self.savedVars.standardKeyboadLH)
		else
			self.lootHistory:Enable(enabled, self.savedVars.standardKeyboadLH)
		end
		
		self.lootHistory:UpdateFonts(self.savedVars)
	end,
	['dynamicChatPosition'] = function(self, enabled)
		if not enabled and not self.chatPosition then return end
		
		if not self.chatPosition then
			self.chatPosition = IJA_GamepadUIVisibility_ChatPosition_Initialize(enabled)
		else
			self.chatPosition:Enable(enabled)
		end
	end,
	['moveHudMeters'] = function(self, enabled)
		if not enabled and not self.hudMeters then return end
		
		if not self.hudMeters then
			self.hudMeters = IJA_GamepadUIVisibility_MoveHudMeters_Initialize(enabled)
		else
			self.hudMeters:Enable(enabled)
		end
	end,
	['resizeActionBar'] = function(self, enabled)
	--d( enabled)
		local scale = enabled and self.savedVars.scale or 1
	--d( scale)
		ZO_ActionBar1:SetScale(scale)
	end,
}

function UIVisibility:ToggleOption(option)
	local enabled = self.savedVars[option] and isGamepadMode or false
	self:Toggle(option, enabled)
end

function UIVisibility:GetToggleFunction(option)
	return toggleOptions[option]
end

function UIVisibility:Toggle(option, enabled)
	self:GetToggleFunction(option)(self, enabled)
end

--------------------------------------------------------------------------------
-- Settings menu
--------------------------------------------------------------------------------

function UIVisibility:SetupSettings()
	local LAM2 = LibAddonMenu2
	if not LAM2 then
		return
	end
	
	local function setLootOption(option, value)
		self.savedVars[option] = value
		if self.lootHistory then
			self.lootHistory:UpdateFonts(self.savedVars)
			showLootDemo()
		end
	end
	
	local panelData = {
		type = "panel",
		name = self.displayName,
		displayName = self.displayName,
		author = "IsJustaGhost",
		version = self.version,
		registerForRefresh = true,
		registerForDefaults = true
	}
	LAM2:RegisterAddonPanel(self.name .. '_LAM', panelData)

	local optionsTable = {
		{ type = "checkbox",
			name = GetString(SI_IJA_DYNAMIC_CHAT),
			tooltip = GetString(SI_IJA_DYNAMIC_CHAT_TOOLTIP),
			getFunc = function() return self.savedVars.dynamicChatPosition end,
			setFunc = function(value) 
				self.savedVars.dynamicChatPosition = value
				self:ToggleOption('dynamicChatPosition')
			end,
			width = "full",
		},
		{ type = "checkbox",
			name = GetString(SI_IJA_SIMPLE_CHAT),
			tooltip = GetString(SI_IJA_SIMPLE_CHAT_TOOLTIP),
			getFunc = function() return self.savedVars.simpleChatPosition end,
			setFunc = function(value)
				self.savedVars.simpleChatPosition = value
				self.chatPosition:OnUpdate()
			end,
			width = "full",
			disabled = function() return not self.savedVars.dynamicChatPosition end,
		},
		{ type = "divider",
			height = 10,
		},
		{ type = "checkbox",
			name = GetString(SI_IJA_LOOTHISTORY_MOVE),
			tooltip = GetString(SI_IJA_LOOTHISTORY_MOVE_TOOLTIP),
			getFunc = function() return self.savedVars.moveLootHistory end,
			setFunc = function(value) 
				self.savedVars.moveLootHistory = value
				self:ToggleOption('moveLootHistory')
				showLootDemo()
			end,
			width = "full",
		},
		{ type = "checkbox",
			name = GetString(SI_IJA_LOOTHISTORY_BASE),
			tooltip = GetString(SI_IJA_LOOTHISTORY_BASE_TOOLTIP),
			getFunc = function() return self.savedVars.standardKeyboadLH end,
			setFunc = function(value) 
				self.savedVars.standardKeyboadLH = value
				self:ToggleOption('moveLootHistory')
				showLootDemo()
			end,
			disabled = function() return self.savedVars.moveLootHistory end,
			width = "full",
		},
		{ type = "dropdown",
			reference = "IJA_GamepadUIVisibility_OverlayFont",
			choices = fontSizes,
			choicesValues = fontList,
			name = GetString(SI_IJA_LOOTHISTORY_FONTS_OVERLAY),
			getFunc = function()
				return self.savedVars.lootHistoryOverlayFont
			end,
			setFunc = function(value)
				setLootOption('lootHistoryOverlayFont', value)
			end,
			width = "full",
			disabled = function() return not self.lootHistory end,
			visible = function() return self.lootHistory ~= nil end,
		},
		{ type = "dropdown",
			reference = "IJA_GamepadUIVisibility_LabelFont",
			choices = fontSizes,
			choicesValues = fontList,
			name = GetString(SI_IJA_LOOTHISTORY_FONTS_LABEL),
			getFunc = function()
				return self.savedVars.lootHistoryLabelFont
			end,
			setFunc = function(value)
				setLootOption('lootHistoryLabelFont', value)
			end,
			width = "full",
			disabled = function() return not self.lootHistory end,
			visible = function() return self.lootHistory ~= nil end,
		},
		{ type = "divider",
			height = 10,
		},
		{ type = "checkbox",
			name = GetString(SI_IJA_HUDMETERS_MOVE),
			tooltip = GetString(SI_IJA_HUDMETERS_MOVE_TOOLTIP),
			getFunc = function() return self.savedVars.moveHudMeters end,
			setFunc = function(value) 
				self.savedVars.moveHudMeters = value
				self:ToggleOption('moveHudMeters')
			end,
			width = "full",
		},
		
		--[[
		{ type = "divider",
			height = 10,
		},
		{ type = "slider",		-- actionBar scale
            name = GetString(SI_IJA_HUDMETERS_MOVE),
			tooltip = GetString(SI_IJA_HUDMETERS_MOVE_TOOLTIP),
			min = 0.2,
			max = 2,
			step = 0.1,
			decimals = 1,
			getFunc = function() return self.savedVars.scale end,
			setFunc = function(value)
				self.savedVars.scale = value
				self:ToggleOption('resizeActionBar')
			end,
			width = "full",
		},
		]]
	}
	LAM2:RegisterOptionControls(self.name .. '_LAM', optionsTable)
end

--------------------------------------------------------------------------------
-- XML Handlers
--------------------------------------------------------------------------------

function IJA_GamepadUIVisibility_Initialize(...)
	IJA_GAMEPADUIVISIBILITY = UIVisibility:New(...)
end

UIVisibility.showLootDemo = showLootDemo
--[[

/script IJA_GAMEPADUIVISIBILITY.showLootDemo()

/script IJA_GAMEPADUIVISIBILITY.doDebug = true

user:/AddOns/IsJustaGamepadUIVisibility/optionals/lootHistory.lua:22: attempt to 


/script SetGamepadVibration(2000, 1, 1)
/script SetGamepadVibration(2000, 5, 5)
/script d(IJA_GAMEPADUIVISIBILITY.chatPosition.currentLayoutPosition)
/script IJA_GAMEPADUIVISIBILITY.chatPosition:OnUpdate()
/script IJA_GAMEPADUIVISIBILITY.chatPosition:SetNewPosition()
/script IJA_GAMEPADUIVISIBILITY.chatPosition.lastLayoutPosition = 2
/script IJA_GAMEPADUIVISIBILITY.chatPosition.currentLayoutPosition = 0


/script d(KEYBOARD_CHAT_SYSTEM.control:GetAnchor(0))

champion scene does not reposition chat if opened before chat is showing
does if chat is used

1.0.5
changed IJA_GamepadUIVisibility_DynamicChatPosition loop


TEST scenes
--]]