------------------------------------------------
-- English localization
------------------------------------------------

local strings = {
	SI_IJA_DYNAMIC_CHAT					= 'Dynamic Chat Position',
	SI_IJA_DYNAMIC_CHAT_TOOLTIP			= 'Enabled: the "Keyboard Chat" window will reposition dynamically based on what Gamepad UI is displayed.',

	SI_IJA_SIMPLE_CHAT					= 'Simple Chat Position',
	SI_IJA_SIMPLE_CHAT_TOOLTIP			= 'Enabled: the "Keyboard Chat" window will not follow displayed UI elements. Instead, it will move to far right at bottom or above the keybind strip.',
	
	SI_IJA_LOOTHISTORY_MOVE				= 'Use modded Keyboard Loot History',
	SI_IJA_LOOTHISTORY_MOVE_TOOLTIP 	= 'Enabled: sets Gamepad Loot History to use a modded Keyboard Loot History clone.',
			
	SI_IJA_LOOTHISTORY_BASE				= 'Use standard Keyboard Loot History',
	SI_IJA_LOOTHISTORY_BASE_TOOLTIP 	= 'Enabled: sets Gamepad Loot History to use the standard Keyboard Loot History.',
			
	SI_IJA_LOOTHISTORY_FONTS_OVERLAY	= 'Set Icon Overlay Text Font',
	SI_IJA_LOOTHISTORY_FONTS_LABEL		= 'Loot Text Font',
	
	SI_IJA_HUDMETERS_MOVE				= 'Move HUD Meters',
	SI_IJA_HUDMETERS_MOVE_TOOLTIP		= 'Enabled: will use the keyboard Telvar, Infamy, and Daedric energy meters',
}

for stringId, stringValue in pairs(strings) do
	ZO_CreateStringId(stringId, stringValue)
	SafeAddVersion(stringId, 1)
end
