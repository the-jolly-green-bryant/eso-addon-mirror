
--------------------------------------------------------------------------------
-- Loot history
--------------------------------------------------------------------------------

local LootHistory = ZO_LootHistory_Shared:Subclass()

--------------------------------------------------------------------------------
-- 
--------------------------------------------------------------------------------

local rowPadding = 8
local minMidth = 282

local function setDimensions(control, width, height)
	if not control:IsHidden() then
		control:SetDimensions(width, height)
	end
end

local function getRowHeight(font)
	return font:match('%d+') + rowPadding
end

local function updateRow(control, maxWidth)
	local parent = control:GetParent()
	control.label:SetFont(LootHistory.lootHistoryLabelFont)
	control.iconOverlayText:SetFont(LootHistory.lootHistoryOverlayFont)
	
	local rowHeight = zo_max(getRowHeight(LootHistory.lootHistoryLabelFont), getRowHeight(LootHistory.lootHistoryOverlayFont))
	
	local iconSize = rowHeight - 4
	setDimensions(control.icon, iconSize, iconSize)
	setDimensions(control.statusIcon, iconSize, iconSize)
	
    local fontObject = _G[LootHistory.lootHistoryLabelFont]
	local labelWidth = GetStringWidthScaled(fontObject, control.label:GetText(), 1, SPACE_INTERFACE) + 100
	
	local labelWidth = zo_max(labelWidth, minMidth)
	if labelWidth > maxWidth then
		maxWidth = labelWidth
	end
	
	control.label:SetDimensionConstraints(minMidth, 20, maxWidth, rowHeight)
	control:SetDimensionConstraints(minMidth, 20, maxWidth, rowHeight)
	
	setDimensions(control, maxWidth, rowHeight)
	setDimensions(control.label, maxWidth, rowHeight)
	setDimensions(control.backgroundHighlight, maxWidth, rowHeight)
	return maxWidth
end

local updating = false
local function updateStreams(self)
	if not updating then
		updating = true
		local maxWidth = 0
		
		for k, stream in ipairs({'lootStream', 'lootStreamPersistent'}) do
			local streamObject = self[stream]
			if streamObject and #streamObject.activeEntries > 0 then
				for k, entry in pairs(streamObject.activeEntries) do
					if entry.Update then
						entry:Update()
					elseif entry.activeLines then
						for k, line in pairs(entry.activeLines) do
							maxWidth = updateRow(line, maxWidth)
						end
					else
						maxWidth = updateRow(entry, maxWidth)
					end
				end
			end
		end
		updating = false
	end
end

local FLUSH_UPDATE_TIME_MS = 200
local nextTimeToFlushMS = 0
local function postInitializeStreams(object)
	local lastControl
	for k, stream in ipairs({'lootStream', 'lootStreamPersistent'}) do
		local streamObject = object[stream]
		if not streamObject.UpdateStreams then
			streamObject.UpdateStreams = updateStreams
		
			local orig_onUpdateBuffer = streamObject.OnUpdateBuffer
			streamObject.OnUpdateBuffer = function(self, timeMs)
				local queuedBatches = self.queuedBatches
				
				orig_onUpdateBuffer(self, timeMs)
				
				if timeMs > nextTimeToFlushMS then
					nextTimeToFlushMS = timeMs + FLUSH_UPDATE_TIME_MS
					updateStreams(object)
				end
			end


			local orig_displayBatches = streamObject.DisplayBatches
			streamObject.DisplayBatches = function(self)
				orig_displayBatches(self)
				updateStreams(object)
			end
	
			local orig_equalitySetup = streamObject.templates[object.entryTemplate].equalitySetup
			streamObject.templates[object.entryTemplate].equalitySetup =  function(fadingControlBuffer, currentEntry, newEntry)
				local currentEntryData = currentEntry.lines[1]
				if currentEntryData.entryType == LOOT_ENTRY_TYPE_COMPANION_EXPERIENCE then
					local newEntryData = newEntry.lines[1]
					local control = currentEntryData.control
					currentEntryData.gainedXp = currentEntryData.gainedXp + newEntryData.gainedXp
					
					if control then
						ZO_CraftingResults_Base_PlayPulse(control.iconOverlayText) -- added animation to icon text?
					end
				else
					orig_equalitySetup(fadingControlBuffer, currentEntry, newEntry)
				end
			end
			
		end
	end
end

local function postInitialize(object)
	if not object.lootStream.UpdateStreams then
		object.CanShowItemsInHistory = LootHistory.CanShowItemsInHistory
		object.AddCompanionXpEntry = LootHistory.AddCompanionXpEntry
		object.OnCompanionRapportUpdate = LootHistory.OnCompanionRapportUpdate
		object.AddCompanionRapportEntry = LootHistory.AddCompanionRapportEntry
--		object.PurgeLootQueue = LootHistory.PurgeLootQueue
		postInitializeStreams(object)
	end
end

--------------------------------------------------------------------------------
-- Shared
--------------------------------------------------------------------------------

local function flushEntries(self)
	if self.lastAnchoredEntry then
		self.lastAnchoredEntry = nil
		self:ReleaseAllControls()
	end
	
--	self.containerStartTimeMs = GetFrameTimeMilliseconds()
	ZO_ClearNumericallyIndexedTable(self.queuedTimedEntries)
	ZO_ClearNumericallyIndexedTable(self.queuedBatches)
	ZO_ClearNumericallyIndexedTable(self.queue)
end

local function purgeLootQueue(object, ...)
	for k, stream in pairs({'lootStream', 'lootStreamPersistent'}) do
		flushEntries(object[stream])
	end
end

function LootHistory:PurgeLootQueue()
	for k, stream in pairs({'lootStream', 'lootStreamPersistent'}) do
	
		ZO_ClearNumericallyIndexedTable(self[stream].queuedTimedEntries)
		self[stream]:FadeAll()
		self[stream]:ReleaseAllControls()
	end
end

--------------------------------------------------------------------------------
-- 
--------------------------------------------------------------------------------

function LootHistory:New(...)
	return ZO_LootHistory_Shared.New(self, ...)
end

function LootHistory:Initialize(control)
	self.control = control
    ZO_LootHistory_Shared.Initialize(self, control)
end

function LootHistory:SetEntryTemplate()
	self.entryTemplate = 'ZO_LootHistory_KeyboardEntry'
end

do
	local SUPPORTED_SCENES = {
        ["gamepadTrade"] = true,
        ["playerSubmenu"] = true, -- Need this for daily login since this is the scene it exists in
        ["gameMenuInGame"] = true,
        ["gamepadInteract"] = true,
        ["crownCrateGamepad"] = true,
        ["mailManagerGamepad"] = true,
        ["gamepad_stats_root"] = true,
        ["codeRedemptionGamepad"] = true,
        ["gamepad_inventory_root"] = true,
        ["gamepad_market_purchase"] = true,
        ["giftInventoryViewGamepad"] = true,
        ["LevelUpRewardsClaimGamepad"] = true,
	}
	function LootHistory:CanShowItemsInHistory()
        local currentSceneName = SCENE_MANAGER:GetCurrentSceneName()
        return not self.hidden or SUPPORTED_SCENES[currentSceneName] or SCENE_MANAGER:IsSceneOnStack("gamepad_inventory_root")
	end
end

do
	local STATUS_ICONS =
	{
		[ZO_LOOT_HISTORY_DISPLAY_TYPE_CRAFT_BAG] = "EsoUI/Art/HUD/lootHistory_icon_craftBag.dds",
		[ZO_LOOT_HISTORY_DISPLAY_TYPE_STOLEN] = "EsoUI/Art/Inventory/inventory_stolenItem_icon.dds",
		[ZO_LOOT_HISTORY_DISPLAY_TYPE_COLLECTIONS] = "EsoUI/Art/HUD/Keyboard/lootHistory_icon_collections.dds",
		[ZO_LOOT_HISTORY_DISPLAY_TYPE_ANTIQUITIES] = "EsoUI/Art/HUD/Keyboard/lootHistory_icon_antiquities.dds",
		[ZO_LOOT_HISTORY_DISPLAY_TYPE_CROWN_CRATE] = "EsoUI/Art/HUD/Keyboard/lootHistory_icon_crownCrates.dds",
	}

	function LootHistory:GetStatusIcon(displayType)
		return STATUS_ICONS[displayType]
	end
end

do
	local HIGHLIGHTS =
	{
		[ZO_LOOT_HISTORY_DISPLAY_TYPE_CRAFT_BAG] = "EsoUI/Art/HUD/lootHistory_highlight.dds",
		[ZO_LOOT_HISTORY_DISPLAY_TYPE_STOLEN] = "EsoUI/Art/HUD/lootHistory_highlight_stolen.dds",
		[ZO_LOOT_HISTORY_DISPLAY_TYPE_COLLECTIONS] = "EsoUI/Art/HUD/lootHistory_highlight.dds",
		[ZO_LOOT_HISTORY_DISPLAY_TYPE_ANTIQUITIES] = "EsoUI/Art/HUD/lootHistory_highlight.dds",
		[ZO_LOOT_HISTORY_DISPLAY_TYPE_CROWN_CRATE] = "EsoUI/Art/HUD/lootHistory_highlight.dds",
	}

	function LootHistory:GetHighlight(displayType)
		return HIGHLIGHTS[displayType]
	end
end

do
	internalassert(BONUS_DROP_SOURCE_MAX_VALUE == 1, "Add icons for new Bonus Drop Source values.")
	local BONUS_DROP_SOURCE_ICONS =
	{
		[BONUS_DROP_SOURCE_COMPANION] = "EsoUI/Art/HUD/lootHistory_bonusDropSourceIcon_companion.dds",
	}

	function LootHistory:GetBonusDropSourceIcon(bonusDropSource)
		return BONUS_DROP_SOURCE_ICONS[bonusDropSource]
	end
end

function LootHistory:InitializeFragment()
	self.fragment = ZO_HUDFadeSceneFragment:New(ZO_LootHistoryControl_Keyboard)
	self.fragment:RegisterCallback("StateChange", function(oldState, newState)
		if newState == SCENE_FRAGMENT_SHOWN then
			self:DisplayLootQueue()
		elseif newState == SCENE_FRAGMENT_HIDING then
			self:HideLootQueue()
		end
	end)
	
	SCENE_MANAGER:GetScene("gameMenuInGame"):RegisterCallback("StateChange", function(oldState, newState)
		if newState == SCENE_SHOWN then
		elseif newState == SCENE_HIDDEN then
			local object = SYSTEMS:GetGamepadObject(ZO_LOOT_HISTORY_NAME)
			purgeLootQueue(object)
		end
	end)
end

function LootHistory:InitializeFadingControlBuffer(control)
	local HORIZ_OFFSET = 0
	local VERTICAL_OFFSET = -84
	local MAX_ENTRIES = 6
	local CONTAINER_SHOW_TIME_MS = self:GetContainerShowTime()
	local PERSISTENT_CONTAINER_SHOW_TIME_MS = self:GetPersistentContainerShowTime()
	local anchor = ZO_Anchor:New(BOTTOMRIGHT, GuiRoot, BOTTOMRIGHT, HORIZ_OFFSET, VERTICAL_OFFSET)

	self.lootStreamPersistent = self:CreateFadingStationaryControlBuffer(control:GetNamedChild("PersistentContainer"), "ZO_LootHistory_FadeShared", "ZO_LootHistory_IconEntranceShared", "ZO_LootHistory_ContainerFadeShared", anchor, MAX_ENTRIES, PERSISTENT_CONTAINER_SHOW_TIME_MS, "CustomGamepadPersistent")
	self.lootStream = self:CreateFadingStationaryControlBuffer(control:GetNamedChild("Container"), "ZO_LootHistory_FadeShared", "ZO_LootHistory_IconEntranceShared", "ZO_LootHistory_ContainerFadeShared", anchor, MAX_ENTRIES, CONTAINER_SHOW_TIME_MS, "CustomGamepad")

	self.lootStreamPersistent:SetAdditionalEntrySpacingY(ZO_KEYBOARD_LOOT_HISTORY_ENTRY_SPACING_Y)
	self.lootStream:SetAdditionalEntrySpacingY(ZO_KEYBOARD_LOOT_HISTORY_ENTRY_SPACING_Y)
	
	postInitializeStreams(self)
end

local function enableObject(object, fragmentToAdd, fragmentToRemove)
	local lootPickupGamepadScene = SCENE_MANAGER:GetScene("lootGamepad")
	local gameMenuInGameScene = SCENE_MANAGER:GetScene("gameMenuInGame")

	SYSTEMS:GetSystem(ZO_LOOT_HISTORY_NAME).gamepadObject = object
		
	lootPickupGamepadScene:RemoveFragment(fragmentToRemove)
	lootPickupGamepadScene:AddFragment(fragmentToAdd)
	
	-- added to allow the loot demo to be seen while in options
	gameMenuInGameScene:RemoveFragment(fragmentToRemove)
	gameMenuInGameScene:AddFragment(fragmentToAdd)
	
	object:DisplayLootQueue()
end

function LootHistory:Enable(enabled, useBase)
	if self.enabled ~= enabled or self.useBase ~= useBase then
		self.enabled = enabled
		self.useBase = useBase
		
		if enabled then
			enableObject(self, self.fragment, GAMEPAD_LOOT_HISTORY_FRAGMENT)
			purgeLootQueue(LOOT_HISTORY_GAMEPAD)
			purgeLootQueue(LOOT_HISTORY_KEYBOARD)
		elseif useBase then
			enableObject(LOOT_HISTORY_KEYBOARD, KEYBOARD_LOOT_HISTORY_FRAGMENT, self.fragment)
			purgeLootQueue(self)
			purgeLootQueue(LOOT_HISTORY_GAMEPAD)
		else
			enableObject(LOOT_HISTORY_GAMEPAD, GAMEPAD_LOOT_HISTORY_FRAGMENT, self.fragment)
			
			purgeLootQueue(self)
			purgeLootQueue(LOOT_HISTORY_KEYBOARD)
		end
	end
end

function LootHistory:UpdateLootHistory(enabled)
end

function LootHistory:UpdateFonts(savedVars)
	LootHistory.lootHistoryOverlayFont = savedVars.lootHistoryOverlayFont
	LootHistory.lootHistoryLabelFont = savedVars.lootHistoryLabelFont
	
--	postInitialize(SYSTEMS:GetGamepadObject(ZO_LOOT_HISTORY_NAME))
	nextTimeToFlushMS = 0
end

--------------------------------------------------------------------------------
-- 
--------------------------------------------------------------------------------

do
	local RAPPORT_INCREASE_BACKGROUND_COLOR = ZO_ColorDef:New("102d0b")
	local RAPPORT_DECREASE_BACKGROUND_COLOR = ZO_ColorDef:New("3f0a0a")
	local COMPANION_NAME_COLOR				= ZO_ColorDef:New(GetInterfaceColor(INTERFACE_COLOR_TYPE_UNIT_REACTION_COLOR, UNIT_REACTION_COLOR_COMPANION))

    function LootHistory:AddCompanionXpEntry(companionId, xpAdded)
        local collectibleId = GetCompanionCollectibleId(companionId)
        local colorizedCompanionName = COMPANION_NAME_COLOR:Colorize(GetCompanionName(companionId))
        local lootData =  {
            text = zo_strformat(SI_COMPANION_NAME_FORMATTER, colorizedCompanionName),
            icon = GetCollectibleIcon(collectibleId),
         --   stackCount = 1,
            stackCount = xpAdded,
            color = ZO_SELECTED_TEXT,
            companionId = companionId,
            companionName = colorizedCompanionName,
            gainedXp = xpAdded,
            entryType = LOOT_ENTRY_TYPE_COMPANION_EXPERIENCE,
            iconOverlayText = ZO_LootHistory_Shared.GetStackCountStringFromData,
            showIconOverlayText = ZO_LootHistory_Shared.ShouldShowStackCountStringFromData
        }
        local lootEntry = self:CreateLootEntry(lootData)
        lootEntry.isPersistent = true
        self:InsertOrQueue(lootEntry)
    end

    function LootHistory:AddCompanionRapportEntry(companionId, isIncrease, adjustmentAmountType, rapport)
        local colorizedCompanionName = COMPANION_NAME_COLOR:Colorize(GetCompanionName(companionId))
        local iconFormatter = isIncrease and LOOT_RAPPORT_INCREASE_ICON_FORMATTER or LOOT_RAPPORT_DECREASE_ICON_FORMATTER
        local lootData = {
            text = zo_strformat(SI_COMPANION_NAME_FORMATTER, colorizedCompanionName),
            icon = string.format(iconFormatter, adjustmentAmountType),
            color = ZO_SELECTED_TEXT,
            backgroundColor = isIncrease and RAPPORT_INCREASE_BACKGROUND_COLOR or RAPPORT_DECREASE_BACKGROUND_COLOR,
            companionId = companionId,
            companionName = colorizedCompanionName,
            entryType = LOOT_ENTRY_TYPE_COMPANION_RAPPORT,
			stackCount = rapport,
            iconOverlayText = ZO_LootHistory_Shared.GetStackCountStringFromData,
            showIconOverlayText = true
        }
        local lootEntry = self:CreateLootEntry(lootData)
        lootEntry.isPersistent = true
        self:InsertOrQueue(lootEntry)
    end
	
	function LootHistory:OnCompanionRapportUpdate(companionId, previousRapport, currentRapport, adjustmentAmountType)
		if currentRapport ~= previousRapport then
			self:AddCompanionRapportEntry(companionId, currentRapport > previousRapport, adjustmentAmountType, currentRapport - previousRapport)
		end
	end
end

--------------------------------------------------------------------------------
-- 
--------------------------------------------------------------------------------

function IJA_GamepadUIVisibility_LootHistory_Initialize(enabled)
	postInitialize(LOOT_HISTORY_GAMEPAD)

	local LootHistory_object = LootHistory:New(IJA_LootHistoryControl_Keyboard)
	LootHistory_object:Enable(enabled)
	return LootHistory_object
end
