local debugOn = false
--------------------------------------------------------------------------------
-- Meter templates
--------------------------------------------------------------------------------
local original_gamepadStyleTelvarMeter = HUD_TELVAR_METER.gamepadStyle
local original_gamepadStyleDaedricEnergyMeter = HUD_DAEDRIC_ENERGY_METER.gamepadStyle

local infamyMeter = {
	keyboardStyle = { 
		template = "ZO_HUDInfamyMeter_KeyboardTemplate" ,
		currencyOptions = 
		{
			showTooltips = true,
			isGamepad = false,
			font = "ZoFontGameLargeBold",
			iconSide = RIGHT,
			overrideTexture = nil
		},
	},
	gamepadStyle = { 
		template = "ZO_HUDInfamyMeter_GamepadTemplate",
		currencyOptions = 
		{
			showTooltips = false,
			isGamepad = true,
			font = "ZoFontGamepadHeaderDataValue",
			iconSide = RIGHT,
			overrideTexture = ZO_Currency_GetGamepadCurrencyIcon(CURT_MONEY)
		},
	},
}

local isEnabled = false
local isGamepadMode

local HudMeters = {}
function HudMeters:Enable(enabled)
	self.enabled = enabled
	self:Initialize()
	
	isGamepadMode = IsInGamepadPreferredMode()
	local styleTable = enabled and HUD_DAEDRIC_ENERGY_METER.keyboardStyle or original_gamepadStyleTelvarMeter
	if HUD_DAEDRIC_ENERGY_METER.gamepadStyle ~= styleTable then
		HUD_DAEDRIC_ENERGY_METER.gamepadStyle = styleTable
		HUD_DAEDRIC_ENERGY_METER.platformStyle:Apply()
	end
	
	if debugOn then
		local UPDATE_TYPE_EVENT = 1
		HUD_INFAMY_METER:OnInfamyUpdated(UPDATE_TYPE_EVENT)
	end
end

function HudMeters:Initialize()
	if self.initialized then return end
	self.initialized = true
	
	ZO_PreHook(HUD_INFAMY_METER, 'OnInfamyUpdated', function(HUDInfamyMeter, updateType)
		isGamepadMode = IsInGamepadPreferredMode()
		if isGamepadMode then
			local gamepadModeSwitchUpdate = isGamepadMode ~= self.isInGamepadMode
			
			if gamepadModeSwitchUpdate then
				local styleTable = self.enabled and infamyMeter.keyboardStyle or infamyMeter.gamepadStyle
				ApplyTemplateToControl(HUDInfamyMeter.control, styleTable.template)
				HUDInfamyMeter.currencyOptions = styleTable.currencyOptions
				HUDInfamyMeter.isInGamepadMode = true
				ZO_CurrencyControl_SetSimpleCurrency(HUDInfamyMeter.bountyLabel, CURT_MONEY, GetFullBountyPayoffAmount(), styleTable.currencyOptions, CURRENCY_SHOW_ALL, true) 
			end
		end
	end)
	
	SecurePostHook(HUD_TELVAR_METER, 'UpdatePlatformStyle', function(HUDTelvarMeter, updateType)
		isGamepadMode = IsInGamepadPreferredMode()
		
		if isGamepadMode then
			local styleTable = self.enabled and HUDTelvarMeter.keyboardStyle or original_gamepadStyleTelvarMeter
		
			if HUDTelvarMeter.gamepadStyle ~= styleTable then
				HUDTelvarMeter.gamepadStyle = styleTable
				ApplyTemplateToControl(HUDTelvarMeter.control, styleTable.template)
				ZO_CurrencyControl_SetSimpleCurrency(HUDTelvarMeter.telvarDisplayControl, CURT_TELVAR_STONES, GetCurrencyAmount(CURT_TELVAR_STONES, CURRENCY_LOCATION_CHARACTER), styleTable.currencyOptions, CURRENCY_SHOW_ALL) 
			end
		end
	end)
end

function IJA_GamepadUIVisibility_MoveHudMeters_Initialize(enabled)
	HudMeters:Enable(enabled)
	return HudMeters
end
